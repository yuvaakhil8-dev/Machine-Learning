import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

def load_project_data(csv_path, feature_x, feature_y, label_col):
    data = pd.read_csv(csv_path)
    X = data[[feature_x, feature_y]].values
    y = data[label_col].values
    return X, y

def plot_project_scatter(X, y, feature_x, feature_y):
    for i in range(len(X)):
        if y[i] == 0:
            plt.scatter(X[i, 0], X[i, 1], color="blue")
        else:
            plt.scatter(X[i, 0], X[i, 1], color="red")

    plt.xlabel(feature_x)
    plt.ylabel(feature_y)
    plt.title("A6: Project Data Scatter Plot (Safe vs Unsafe)")
    plt.grid(True)
    plt.show()

def plot_knn_decision_boundary(X, y, k_value, feature_x, feature_y):
    model = KNeighborsClassifier(n_neighbors=k_value)
    model.fit(X, y)

    x_min, x_max = X[:, 0].min() - 0.05, X[:, 0].max() + 0.05
    y_min, y_max = X[:, 1].min() - 0.05, X[:, 1].max() + 0.05

    xx, yy = np.meshgrid(
        np.linspace(x_min, x_max, 300),
        np.linspace(y_min, y_max, 300)
    )

    grid_points = np.c_[xx.ravel(), yy.ravel()]
    predictions = model.predict(grid_points).reshape(xx.shape)

    plt.contourf(xx, yy, predictions, alpha=0.3)

    for i in range(len(X)):
        if y[i] == 0:
            plt.scatter(X[i, 0], X[i, 1], color="blue")
        else:
            plt.scatter(X[i, 0], X[i, 1], color="red")

    plt.xlabel(feature_x)
    plt.ylabel(feature_y)
    plt.title(f"A6: kNN Decision Boundary (k = {k_value})")
    plt.grid(True)
    plt.show()

def main():
    csv_path = "dataset_1.csv"

    feature_x = "avg_motion_intensity"
    feature_y = "unsafe_object_score"
    label_col = "label"

    X, y = load_project_data(csv_path, feature_x, feature_y, label_col)

    plot_project_scatter(X, y, feature_x, feature_y)

    plot_knn_decision_boundary(X, y, 3, feature_x, feature_y)

    for k in [1, 3, 5, 7]:
        plot_knn_decision_boundary(X, y, k, feature_x, feature_y)
if __name__ == "__main__":
    main()
