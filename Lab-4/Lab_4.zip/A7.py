import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score

def load_project_data(csv_path, label_col):
    data = pd.read_csv(csv_path)
    X = data.drop(columns=["video_id", label_col]).values
    y = data[label_col].values
    return X, y

def split_data(X, y, test_ratio):
    return train_test_split(X, y, test_size=test_ratio, random_state=42)

def find_best_k(X_train, y_train):
    param_grid = {
        "n_neighbors": [1, 3, 5, 7, 9, 11, 13, 15]
    }

    knn = KNeighborsClassifier()

    grid_search = GridSearchCV(
        estimator=knn,
        param_grid=param_grid,
        cv=5,
        scoring="f1",
        n_jobs=-1
    )

    grid_search.fit(X_train, y_train)

    return grid_search.best_estimator_, grid_search.best_params_

def evaluate_model(model, X_train, X_test, y_train, y_test):
    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)

    metrics = {
        "train_confusion": confusion_matrix(y_train, train_pred),
        "test_confusion": confusion_matrix(y_test, test_pred),
        "precision": precision_score(y_test, test_pred),
        "recall": recall_score(y_test, test_pred),
        "f1_score": f1_score(y_test, test_pred)
    }

    return metrics

def main():
    csv_path = "dataset_1.csv"
    label_col = "label"

    X, y = load_project_data(csv_path, label_col)
    X_train, X_test, y_train, y_test = split_data(X, y, 0.3)

    best_model, best_params = find_best_k(X_train, y_train)

    results = evaluate_model(best_model, X_train, X_test, y_train, y_test)

    print("Best k value found:", best_params["n_neighbors"])
    print("\nTrain Confusion Matrix:\n", results["train_confusion"])
    print("\nTest Confusion Matrix:\n", results["test_confusion"])
    print("\nTest Precision:", results["precision"])
    print("Test Recall   :", results["recall"])
    print("Test F1-Score :", results["f1_score"])

if __name__ == "__main__":
    main()
